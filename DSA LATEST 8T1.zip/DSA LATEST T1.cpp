#include <iostream>
#include <string>

using namespace std;

class Book {
public:
    string title;
    float price;
    int edition;
    int pages;

    Book() {}

    Book(string t, float p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
    }
};

class Stack {
private:
    Book books[5]; 
    int top;

public:
    Stack() {
        top = -1; 
    }

    void push(string title, float price, int edition, int pages) {
        if (top == 5 - 1) {
            cout << "Stack overflow! Cannot add more books." << endl;
        } else {
            top++;
            books[top] = Book(title, price, edition, pages);
            cout << "Book added: " << title << endl;
        }
    }

    Book pop() {
        if (top == -1) {
            cout << "Stack underflow! No books to remove." << endl;
            return Book(); 
        } else {
            Book poppedBook = books[top];
            top--;
            return poppedBook;
        }
    }

    Book peek() {
        if (top == -1) {
            cout << "Stack is empty!" << endl;
            return Book(); 
        } else {
            return books[top];
        }
    }

    void display() {
        if (top < 0) {
            cout << "Stack is empty!" << endl;
        } else {
            cout << "Stack elements are: " << endl;
            for (int i = 0; i <= top; i++) {
                cout << "Title: " << books[i].title 
                     << ", Price: " << books[i].price 
                     << ", Edition: " << books[i].edition 
                     << ", Pages: " << books[i].pages << endl;
            }
        }
    }
};

int main() {
    Stack myStack;

    
    myStack.push("Book 1", 29.99, 1, 300);
    myStack.push("Book 2", 39.99, 2, 400);
    myStack.push("Book 3", 49.99, 3, 500);
    myStack.push("Book 4", 59.99, 4, 600);
    myStack.push("Book 5", 69.99, 5, 700);

   
    Book topBook = myStack.peek();
    cout << "Top element is: " << topBook.title << endl;

    
    Book removedBook1 = myStack.pop();
    cout << "Removed book: " << removedBook1.title << endl;

    Book removedBook2 = myStack.pop();
    cout << "Removed book: " << removedBook2.title << endl;

  
    myStack.display();

    return 0;
}